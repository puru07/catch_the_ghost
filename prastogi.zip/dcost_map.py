import state_node_d
from state_node_d import state_node
import operator as op

def dcost_map(prob,start,goal):
	map_dji =  dji(prob,goal)
	#print len(map_dji)
	return map_dji

def dji(prob,goal):
	weight = 1
	closed_dict = {}
	open_dict = {}
	hash_return = {}
	for item in goal:
		start_node = state_node(0,item[0],item[1],0,prob)
		open_dict.update({start_node:start_node.gval})
		hash_return[hash_fn(item[0],item[1],prob.grid)] = prob.cost[item[0]][item[1]]
	#print len(open_dict)
	i = 0
	while True:
		# checking if any viable node is left in open dict:
		try:
			node_to_expand = min(open_dict.items(), key=op.itemgetter(1))
		except ValueError:
			return hash_return
		del open_dict[node_to_expand[0]]
		key_check =  hash_fn(node_to_expand[0].row,node_to_expand[0].col,prob.grid)
		try:
			if hash_return[key_check] < node_to_expand[0].gval :
				i += 1
				continue
		except:
			pass
		
		new_dict = node_to_expand[0].expand(prob,closed_dict,open_dict,weight)
		for item in list(new_dict):
			hash_return[hash_fn(item.row,item.col,prob.grid)] = item.gval
			#print hash_fn(item.row,item.col,prob.grid)
		open_dict.update(new_dict)
		
		closed_dict.update({node_to_expand[0]:node_to_expand[1]})
		if len(open_dict) == 0:
			return hash_return


def hash_fn(row,col,grid):
	id = row + col*grid
	return id


def goal_check(node,goal):
	for items in goal:

		if [node.row,node.col]== items:
			return 1
	else:
		return 0 


