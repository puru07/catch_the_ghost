to run the file:

python moving-target-a.py problem_0.txt

python moving-target-b.py problem_0.txt

note: problem dexription file (problem_0.txt / problem_1.txt) should be in the same folder